import '@testing-library/jest-dom';
// import { mutate } from 'swr';

beforeEach(async () => {
  // mutate(() => true, undefined, { revalidate: true });
});
